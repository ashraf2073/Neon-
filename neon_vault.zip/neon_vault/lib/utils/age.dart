/// Calendar-accurate age of a project (years, months, days).
class ProjectAge {
  const ProjectAge({
    required this.years,
    required this.months,
    required this.days,
    required this.totalDays,
  });

  final int years, months, days, totalDays;

  static int _daysIn(int y, int m) => DateTime.utc(y, m + 1, 0).day;

  factory ProjectAge.between(DateTime from, DateTime to) {
    final a = DateTime.utc(from.year, from.month, from.day);
    final b = DateTime.utc(to.year, to.month, to.day);
    if (b.isBefore(a)) {
      return const ProjectAge(years: 0, months: 0, days: 0, totalDays: 0);
    }
    var totalMonths = (b.year - a.year) * 12 + (b.month - a.month);
    if (b.day < a.day) totalMonths -= 1;

    // Anchor = start date + whole months (day clamped to month length).
    final idx = a.month - 1 + totalMonths;
    final ay = a.year + idx ~/ 12;
    final am = idx % 12 + 1;
    final anchorDay = a.day > _daysIn(ay, am) ? _daysIn(ay, am) : a.day;
    final anchor = DateTime.utc(ay, am, anchorDay);

    return ProjectAge(
      years: totalMonths ~/ 12,
      months: totalMonths % 12,
      days: b.difference(anchor).inDays,
      totalDays: b.difference(a).inDays,
    );
  }

  static String _unit(int n, String s) => '$n $s${n == 1 ? '' : 's'}';

  /// "2 years, 3 months" / "5 months" / "12 days"
  String get label {
    if (totalDays == 0) return 'less than a day';
    final parts = <String>[];
    if (years > 0) parts.add(_unit(years, 'year'));
    if (months > 0) parts.add(_unit(months, 'month'));
    if (years == 0 && months == 0) parts.add(_unit(days, 'day'));
    return parts.join(', ');
  }

  /// "2y 3m" / "5m 12d" / "12d"
  String get short {
    if (years > 0) return '${years}y ${months}m';
    if (months > 0) return '${months}m ${days}d';
    return '${days}d';
  }
}

String formatDate(DateTime d) {
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return '${d.day} ${m[d.month - 1]} ${d.year}';
}

String timeAgo(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inSeconds < 45) return 'just now';
  if (d.inMinutes < 60) return '${d.inMinutes} min ago';
  if (d.inHours < 24) return '${d.inHours} h ago';
  return '${d.inDays} d ago';
}
