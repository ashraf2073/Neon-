/// What the user approved on the sign-in screen. Stored on-device only.
class Consent {
  const Consent({
    this.dataAccess = false,
    this.networkChecks = false,
    this.keepSignedIn = false,
    this.registryLookups = false,
    this.grantedAt,
  });

  /// Required: store email, hashed password and project data on this device.
  final bool dataAccess;

  /// Optional: contact the project URLs I added to check uptime.
  final bool networkChecks;

  /// Optional: keep the session between launches.
  final bool keepSignedIn;

  /// Optional: send a domain or repository name to public services
  /// (domain registry, Internet Archive, GitHub) to find a launch date.
  final bool registryLookups;
  final DateTime? grantedAt;

  static const none = Consent();

  Consent copyWith({
    bool? dataAccess,
    bool? networkChecks,
    bool? keepSignedIn,
    bool? registryLookups,
  }) =>
      Consent(
        dataAccess: dataAccess ?? this.dataAccess,
        networkChecks: networkChecks ?? this.networkChecks,
        keepSignedIn: keepSignedIn ?? this.keepSignedIn,
        registryLookups: registryLookups ?? this.registryLookups,
        grantedAt: DateTime.now(),
      );

  Map<String, dynamic> toJson() => {
        'data': dataAccess,
        'net': networkChecks,
        'keep': keepSignedIn,
        'lookup': registryLookups,
        'at': grantedAt?.toIso8601String(),
      };

  factory Consent.fromJson(Map<String, dynamic> j) => Consent(
        dataAccess: j['data'] == true,
        networkChecks: j['net'] == true,
        keepSignedIn: j['keep'] == true,
        registryLookups: j['lookup'] == true,
        grantedAt: j['at'] == null ? null : DateTime.tryParse(j['at'] as String),
      );
}
