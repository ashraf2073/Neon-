import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../utils/age.dart';

enum ProjectCategory { app, web, portfolio }

extension ProjectCategoryX on ProjectCategory {
  String get label => switch (this) {
        ProjectCategory.app => 'App',
        ProjectCategory.web => 'Website',
        ProjectCategory.portfolio => 'Portfolio',
      };

  IconData get icon => switch (this) {
        ProjectCategory.app => Icons.smartphone_rounded,
        ProjectCategory.web => Icons.language_rounded,
        ProjectCategory.portfolio => Icons.auto_awesome_mosaic_rounded,
      };

  Color get color => switch (this) {
        ProjectCategory.app => Neon.blue,
        ProjectCategory.web => Neon.pink,
        ProjectCategory.portfolio => Neon.violet,
      };
}

enum LiveState { live, down, unchecked, archived }

/// One uptime probe. The last ~120 are kept per project.
class UptimeRecord {
  const UptimeRecord({required this.at, required this.up, this.latencyMs, this.statusCode});

  final DateTime at;
  final bool up;
  final int? latencyMs;
  final int? statusCode;

  Map<String, dynamic> toJson() => {
        'at': at.toIso8601String(),
        'up': up,
        'ms': latencyMs,
        'code': statusCode,
      };

  factory UptimeRecord.fromJson(Map<String, dynamic> j) => UptimeRecord(
        at: DateTime.parse(j['at'] as String),
        up: j['up'] as bool,
        latencyMs: j['ms'] as int?,
        statusCode: j['code'] as int?,
      );
}

class Project {
  const Project({
    required this.id,
    required this.name,
    required this.category,
    required this.launchDate,
    this.description = '',
    this.purpose = '',
    this.techStack = const [],
    this.url = '',
    this.logoPath,
    this.archived = false,
    this.archivedAt,
    this.checks = const [],
    this.serverMeta = const {},
  });

  final String id;
  final String name;
  final ProjectCategory category;
  final DateTime launchDate;
  final String description; // short card text
  final String purpose; // "About" section
  final List<String> techStack;
  final String url;
  final String? logoPath;
  final bool archived;
  final DateTime? archivedAt;
  final List<UptimeRecord> checks;
  final Map<String, String> serverMeta; // headers read from the live site

  UptimeRecord? get lastCheck => checks.isEmpty ? null : checks.last;

  /// Raw state from the last probe. Use ProjectsProvider.stateOf() in the UI
  /// so that "checks switched off" is respected.
  LiveState get liveState => archived
      ? LiveState.archived
      : lastCheck == null
          ? LiveState.unchecked
          : (lastCheck!.up ? LiveState.live : LiveState.down);

  double? get uptimePercent =>
      checks.isEmpty ? null : checks.where((c) => c.up).length * 100 / checks.length;

  /// Age is frozen at the archive date for archived projects.
  ProjectAge get age => ProjectAge.between(
        launchDate,
        archived && archivedAt != null ? archivedAt! : DateTime.now(),
      );

  Project copyWith({
    String? name,
    ProjectCategory? category,
    DateTime? launchDate,
    String? description,
    String? purpose,
    List<String>? techStack,
    String? url,
    String? logoPath,
    bool clearLogo = false,
    bool? archived,
    DateTime? archivedAt,
    bool clearArchivedAt = false,
    List<UptimeRecord>? checks,
    Map<String, String>? serverMeta,
  }) =>
      Project(
        id: id,
        name: name ?? this.name,
        category: category ?? this.category,
        launchDate: launchDate ?? this.launchDate,
        description: description ?? this.description,
        purpose: purpose ?? this.purpose,
        techStack: techStack ?? this.techStack,
        url: url ?? this.url,
        logoPath: clearLogo ? null : (logoPath ?? this.logoPath),
        archived: archived ?? this.archived,
        archivedAt: clearArchivedAt ? null : (archivedAt ?? this.archivedAt),
        checks: checks ?? this.checks,
        serverMeta: serverMeta ?? this.serverMeta,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'category': category.name,
        'launch': launchDate.toIso8601String(),
        'description': description,
        'purpose': purpose,
        'stack': techStack,
        'url': url,
        'logo': logoPath,
        'archived': archived,
        'archivedAt': archivedAt?.toIso8601String(),
        'checks': checks.map((c) => c.toJson()).toList(),
        'meta': serverMeta,
      };

  factory Project.fromJson(Map<String, dynamic> j) => Project(
        id: j['id'] as String,
        name: j['name'] as String,
        category: ProjectCategory.values.byName(j['category'] as String),
        launchDate: DateTime.parse(j['launch'] as String),
        description: (j['description'] as String?) ?? '',
        purpose: (j['purpose'] as String?) ?? '',
        techStack: ((j['stack'] as List?) ?? const []).map((e) => '$e').toList(),
        url: (j['url'] as String?) ?? '',
        logoPath: j['logo'] as String?,
        archived: (j['archived'] as bool?) ?? false,
        archivedAt: j['archivedAt'] == null ? null : DateTime.parse(j['archivedAt'] as String),
        checks: ((j['checks'] as List?) ?? const [])
            .map((e) => UptimeRecord.fromJson(e as Map<String, dynamic>))
            .toList(),
        serverMeta: ((j['meta'] as Map?) ?? const {}).map((k, v) => MapEntry('$k', '$v')),
      );
}
