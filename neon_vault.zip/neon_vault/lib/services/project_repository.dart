import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/project.dart';

/// Local persistence. Replace with Firestore/SQLite later without touching UI.
class ProjectRepository {
  static const _key = 'projects.v1';

  Future<List<Project>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) {
      final seed = _seed();
      await save(seed);
      return seed;
    }
    return (jsonDecode(raw) as List)
        .map((e) => Project.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> save(List<Project> projects) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(projects.map((p) => p.toJson()).toList()));
  }

  /// Copies a picked image into app storage so it survives cache clears.
  Future<String> storeLogo(String id, String sourcePath) async {
    final dir = await getApplicationDocumentsDirectory();
    final logos = Directory('${dir.path}/logos');
    if (!await logos.exists()) await logos.create(recursive: true);
    final ext = sourcePath.contains('.') ? sourcePath.split('.').last : 'png';
    final dest = '${logos.path}/$id-${DateTime.now().millisecondsSinceEpoch}.$ext';
    await File(sourcePath).copy(dest);
    return dest;
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
    final dir = await getApplicationDocumentsDirectory();
    final logos = Directory('${dir.path}/logos');
    if (await logos.exists()) await logos.delete(recursive: true);
  }

  /// Sample entries so the dashboard is not empty on first launch.
  List<Project> _seed() => [
        Project(
          id: 'sample-web',
          name: 'Sample website',
          category: ProjectCategory.web,
          url: 'https://example.com',
          launchDate: DateTime(2023, 2, 14),
          description: 'A placeholder site. Edit or delete it.',
          purpose: 'Shows how a live website is tracked: age, response time and uptime.',
          techStack: ['HTML', 'CSS', 'JavaScript'],
        ),
        Project(
          id: 'sample-portfolio',
          name: 'Sample portfolio',
          category: ProjectCategory.portfolio,
          url: 'https://flutter.dev',
          launchDate: DateTime(2024, 6, 3),
          description: 'A placeholder portfolio entry.',
          purpose: 'Shows how portfolio pages are grouped and sorted.',
          techStack: ['Dart', 'Flutter'],
        ),
        Project(
          id: 'sample-app',
          name: 'Sample archived app',
          category: ProjectCategory.app,
          launchDate: DateTime(2021, 9, 20),
          archived: true,
          archivedAt: DateTime(2023, 4, 1),
          description: 'An app that has been retired.',
          purpose: 'Archived projects keep their age frozen at the archive date.',
          techStack: ['Kotlin'],
        ),
      ];
}
