import 'dart:async';

import 'package:http/http.dart' as http;

class UptimeResult {
  UptimeResult({
    required this.up,
    required this.at,
    this.statusCode,
    this.latencyMs,
    this.meta = const {},
    this.error,
  });

  final bool up;
  final DateTime at;
  final int? statusCode;
  final int? latencyMs;
  final Map<String, String> meta;
  final String? error;
}

/// Probes a URL and reads public response headers (server, last-modified...).
/// "Up" means the server answered with anything below HTTP 500.
class UptimeService {
  UptimeService([http.Client? client]) : _client = client ?? http.Client();
  final http.Client _client;

  static const _timeout = Duration(seconds: 8);
  static const _headersWanted = ['server', 'last-modified', 'content-type', 'x-powered-by', 'date'];

  static Uri? normalize(String raw) {
    var s = raw.trim();
    if (s.isEmpty) return null;
    if (!RegExp(r'^https?://', caseSensitive: false).hasMatch(s)) s = 'https://$s';
    final u = Uri.tryParse(s);
    return (u == null || u.host.isEmpty) ? null : u;
  }

  Future<UptimeResult> check(String raw) async {
    final uri = normalize(raw);
    if (uri == null) return UptimeResult(up: false, at: DateTime.now(), error: 'Invalid link');
    final sw = Stopwatch()..start();
    try {
      var res = await _client.head(uri).timeout(_timeout);
      if (const [403, 405, 501].contains(res.statusCode)) {
        res = await _client.get(uri).timeout(_timeout);
      }
      sw.stop();
      return UptimeResult(
        up: res.statusCode < 500,
        at: DateTime.now(),
        statusCode: res.statusCode,
        latencyMs: sw.elapsedMilliseconds,
        meta: {
          for (final k in _headersWanted)
            if (res.headers[k] != null) k: res.headers[k]!,
        },
      );
    } on TimeoutException {
      return UptimeResult(up: false, at: DateTime.now(), error: 'Timed out');
    } catch (e) {
      return UptimeResult(up: false, at: DateTime.now(), error: 'Unreachable');
    }
  }
}
