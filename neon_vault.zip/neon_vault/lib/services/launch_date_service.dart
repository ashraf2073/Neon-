import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'uptime_service.dart';

class LaunchCandidate {
  const LaunchCandidate({required this.date, required this.source, required this.detail});
  final DateTime date;
  final String source;
  final String detail;
}

class LaunchLookupResult {
  const LaunchLookupResult({this.candidates = const [], this.notes = const []});
  final List<LaunchCandidate> candidates; // oldest first
  final List<String> notes; // why a source gave nothing
}

class _Part {
  const _Part([this.candidate, this.note]);
  final LaunchCandidate? candidate;
  final String? note;
}

/// Works out when a project probably started, from its link:
///  - GitHub repository creation date (github.com and *.github.io links)
///  - Domain registration date (public RDAP registry)
///  - First capture in the Internet Archive (Wayback Machine)
/// Returns every date it finds so the user can choose. Nothing is auto-applied.
class LaunchDateService {
  LaunchDateService([http.Client? client]) : _client = client ?? http.Client();
  final http.Client _client;

  static const _timeout = Duration(seconds: 10);

  /// Addresses on these hosts are not the user's own domain, so a registration
  /// date would describe the host, not the project.
  static const _sharedHosts = [
    'github.io', 'github.com', 'gitlab.io', 'vercel.app', 'netlify.app', 'pages.dev',
    'web.app', 'firebaseapp.com', 'herokuapp.com', 'onrender.com', 'glitch.me',
    'repl.co', 'replit.app', 'blogspot.com', 'wordpress.com', 'wixsite.com',
    'weebly.com', 'surge.sh', 'fly.dev', 'railway.app', 'streamlit.app',
    'play.google.com', 'apps.apple.com',
  ];
  static const _noArchive = ['github.com', 'play.google.com', 'apps.apple.com'];
  static const _secondLevel = {
    'co', 'com', 'org', 'net', 'gov', 'edu', 'ac', 'or', 'ne', 'go', 'sc', 'me', 'info', 'mil',
  };

  static bool _isShared(String host) =>
      _sharedHosts.any((s) => host == s || host.endsWith('.$s'));

  static DateTime _dateOnly(DateTime d) {
    final u = d.toUtc();
    return DateTime(u.year, u.month, u.day);
  }

  Future<LaunchLookupResult> find(String raw) async {
    final uri = UptimeService.normalize(raw);
    if (uri == null) return const LaunchLookupResult(notes: ['Add a valid link first.']);
    final host = uri.host.toLowerCase();

    final parts = await Future.wait([_github(uri, host), _rdap(host), _wayback(uri, host)]);

    final candidates = [
      for (final p in parts)
        if (p.candidate != null) p.candidate!,
    ]..sort((a, b) => a.date.compareTo(b.date));
    final notes = [
      for (final p in parts)
        if (p.note != null) p.note!,
    ];
    return LaunchLookupResult(candidates: candidates, notes: notes);
  }

  // ---- GitHub --------------------------------------------------------------

  Future<_Part> _github(Uri uri, String host) async {
    final segs = uri.pathSegments.where((s) => s.isNotEmpty).toList();
    String owner;
    final repos = <String>[];
    if (host == 'github.com' || host == 'www.github.com') {
      if (segs.length < 2) {
        return const _Part(null, 'A GitHub link needs an owner and a repository.');
      }
      owner = segs[0];
      repos.add(segs[1].replaceAll(RegExp(r'\.git$'), ''));
    } else if (host.endsWith('.github.io')) {
      owner = host.split('.').first;
      if (segs.isNotEmpty) repos.add(segs.first);
      repos.add(host);
    } else {
      return const _Part();
    }

    try {
      for (final repo in repos) {
        final res = await _client.get(
          Uri.https('api.github.com', '/repos/$owner/$repo'),
          headers: {'Accept': 'application/vnd.github+json'},
        ).timeout(_timeout);
        if (res.statusCode == 403 || res.statusCode == 429) {
          return const _Part(null, 'GitHub is rate limiting lookups. Try again in an hour.');
        }
        if (res.statusCode != 200) continue;
        final created =
            DateTime.tryParse(((jsonDecode(res.body) as Map<String, dynamic>)['created_at'] as String?) ?? '');
        if (created != null) {
          return _Part(LaunchCandidate(
            date: _dateOnly(created),
            source: 'GitHub repository',
            detail: '$owner/$repo was created',
          ));
        }
      }
      return const _Part(null, 'GitHub repository not found. It may be private.');
    } catch (_) {
      return const _Part(null, 'GitHub lookup failed. Check your connection.');
    }
  }

  // ---- Domain registration (RDAP) -------------------------------------------

  Future<_Part> _rdap(String host) async {
    if (_isShared(host)) {
      return const _Part(null,
          'Domain lookup skipped: this address is on a shared host, so its registration date is not yours.');
    }
    final labels = host.split('.');
    if (labels.length < 2 || RegExp(r'^[0-9.]+$').hasMatch(host)) {
      return const _Part(null, 'Domain lookup skipped: no registrable domain in this link.');
    }
    final names = <String>[];
    if (labels.length >= 3 && _secondLevel.contains(labels[labels.length - 2])) {
      names.add(labels.sublist(labels.length - 3).join('.'));
    }
    names.add(labels.sublist(labels.length - 2).join('.'));

    try {
      for (final name in names) {
        final res = await _client.get(
          Uri.https('rdap.org', '/domain/$name'),
          headers: {'Accept': 'application/rdap+json, application/json'},
        ).timeout(_timeout);
        if (res.statusCode != 200) continue;
        final events = ((jsonDecode(res.body) as Map<String, dynamic>)['events'] as List?) ?? const [];
        for (final e in events) {
          if (e is Map && e['eventAction'] == 'registration') {
            final d = DateTime.tryParse('${e['eventDate']}');
            if (d != null) {
              return _Part(LaunchCandidate(
                date: _dateOnly(d),
                source: 'Domain registration',
                detail: '$name was registered',
              ));
            }
          }
        }
      }
      return const _Part(null, 'No public registration date found for this domain.');
    } catch (_) {
      return const _Part(null, 'Domain lookup failed. Check your connection.');
    }
  }

  // ---- Internet Archive ----------------------------------------------------

  Future<_Part> _wayback(Uri uri, String host) async {
    if (_noArchive.contains(host)) return const _Part();
    final path = uri.pathSegments.where((s) => s.isNotEmpty).join('/');
    final target = _isShared(host) && path.isNotEmpty ? '$host/$path' : host;
    try {
      final res = await _client.get(
        Uri.https('web.archive.org', '/cdx/search/cdx', {
          'url': target,
          'fl': 'timestamp',
          'limit': '1',
          'filter': 'statuscode:200',
        }),
      ).timeout(_timeout);
      if (res.statusCode != 200) {
        return const _Part(null, 'The web archive is unavailable right now.');
      }
      final ts = res.body.trim().split('\n').first.trim();
      if (ts.length < 8) {
        return const _Part(null, 'The web archive has no captures of this address.');
      }
      final d = DateTime.utc(
        int.parse(ts.substring(0, 4)),
        int.parse(ts.substring(4, 6)),
        int.parse(ts.substring(6, 8)),
      );
      return _Part(LaunchCandidate(
        date: _dateOnly(d),
        source: 'First web archive capture',
        detail: 'Earliest snapshot of $target',
      ));
    } catch (_) {
      return const _Part(null, 'Web archive lookup failed. Check your connection.');
    }
  }
}
