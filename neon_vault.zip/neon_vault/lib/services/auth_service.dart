import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/consent.dart';

class AuthException implements Exception {
  AuthException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// UI talks only to this interface. To move to Firebase, implement it with
/// FirebaseAuth (createUserWithEmailAndPassword / signInWithEmailAndPassword)
/// and swap the instance in main.dart. Nothing else changes.
abstract class AuthService {
  Future<bool> hasAccount();
  Future<String?> restoreSession();
  Future<String> register(String email, String password, {required bool persist});
  Future<String> signIn(String email, String password, {required bool persist});
  Future<void> signOut();
  Future<Consent> loadConsent();
  Future<void> saveConsent(Consent consent);
  Future<void> wipe();
}

/// Prototype backend: one account per device, kept in Android Keystore-backed
/// secure storage. The password is never stored, only a salted, iterated hash.
class LocalAuthService implements AuthService {
  LocalAuthService({FlutterSecureStorage? storage})
      : _s = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _s;

  static const _kEmail = 'auth.email';
  static const _kSalt = 'auth.salt';
  static const _kHash = 'auth.hash';
  static const _kSession = 'auth.session';
  static const _kConsent = 'auth.consent';
  static final _emailRe = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

  String _newSalt() {
    final r = Random.secure();
    return base64Url.encode(List<int>.generate(16, (_) => r.nextInt(256)));
  }

  String _hash(String salt, String password) {
    List<int> bytes = utf8.encode('$salt:$password');
    for (var i = 0; i < 12000; i++) {
      bytes = sha256.convert(bytes).bytes;
    }
    return base64Url.encode(bytes);
  }

  bool _same(String a, String b) {
    if (a.length != b.length) return false;
    var r = 0;
    for (var i = 0; i < a.length; i++) {
      r |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
    }
    return r == 0;
  }

  Future<void> _persist(String email, bool persist) => persist
      ? _s.write(key: _kSession, value: email)
      : _s.delete(key: _kSession);

  @override
  Future<bool> hasAccount() async => (await _s.read(key: _kHash)) != null;

  @override
  Future<String?> restoreSession() => _s.read(key: _kSession);

  @override
  Future<String> register(String email, String password, {required bool persist}) async {
    final e = email.trim().toLowerCase();
    if (!_emailRe.hasMatch(e)) throw AuthException('Enter a valid email address.');
    if (password.length < 8) throw AuthException('Use at least 8 characters for your password.');
    if (await hasAccount()) {
      throw AuthException('An account already exists on this device. Sign in instead.');
    }
    final salt = _newSalt();
    await _s.write(key: _kEmail, value: e);
    await _s.write(key: _kSalt, value: salt);
    await _s.write(key: _kHash, value: _hash(salt, password));
    await _persist(e, persist);
    return e;
  }

  @override
  Future<String> signIn(String email, String password, {required bool persist}) async {
    final e = email.trim().toLowerCase();
    final stored = await _s.read(key: _kEmail);
    final salt = await _s.read(key: _kSalt);
    final hash = await _s.read(key: _kHash);
    if (stored == null || salt == null || hash == null) {
      throw AuthException('No account found on this device.');
    }
    if (stored != e || !_same(hash, _hash(salt, password))) {
      throw AuthException('Email or password is incorrect.');
    }
    await _persist(e, persist);
    return e;
  }

  @override
  Future<void> signOut() => _s.delete(key: _kSession);

  @override
  Future<Consent> loadConsent() async {
    final raw = await _s.read(key: _kConsent);
    if (raw == null) return Consent.none;
    return Consent.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  @override
  Future<void> saveConsent(Consent consent) =>
      _s.write(key: _kConsent, value: jsonEncode(consent.toJson()));

  @override
  Future<void> wipe() => _s.deleteAll();
}
