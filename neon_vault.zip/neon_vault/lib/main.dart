import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'core/theme.dart';
import 'providers/auth_provider.dart';
import 'providers/island_controller.dart';
import 'providers/projects_provider.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'services/auth_service.dart';
import 'services/project_repository.dart';
import 'services/uptime_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Neon.midnight,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const NeonVaultApp());
}

class NeonVaultApp extends StatelessWidget {
  const NeonVaultApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => IslandController()),
        // Swap LocalAuthService for a Firebase-backed AuthService here.
        ChangeNotifierProvider(create: (_) => AuthProvider(LocalAuthService())..bootstrap()),
        ChangeNotifierProxyProvider<AuthProvider, ProjectsProvider>(
          lazy: false,
          create: (ctx) => ProjectsProvider(
            ProjectRepository(),
            UptimeService(),
            ctx.read<IslandController>(),
          ),
          update: (_, auth, projects) => projects!
            ..syncWithAuth(
              signedIn: auth.status == AuthStatus.signedIn,
              checksAllowed: auth.consent.networkChecks,
            ),
        ),
      ],
      child: MaterialApp(
        title: 'Neon Vault',
        debugShowCheckedModeBanner: false,
        theme: buildNeonTheme(),
        home: const _AuthGate(),
      ),
    );
  }
}

class _AuthGate extends StatelessWidget {
  const _AuthGate();

  @override
  Widget build(BuildContext context) {
    final status = context.select<AuthProvider, AuthStatus>((a) => a.status);
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 350),
      child: switch (status) {
        AuthStatus.unknown => const _Splash(key: ValueKey('splash')),
        AuthStatus.signedOut => const LoginScreen(key: ValueKey('login')),
        AuthStatus.signedIn => const HomeScreen(key: ValueKey('home')),
      },
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            gradient: Neon.gradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: Neon.glow(Neon.pink, blur: 40),
          ),
          child: const Icon(Icons.hub_rounded, size: 36),
        ),
      ),
    );
  }
}
