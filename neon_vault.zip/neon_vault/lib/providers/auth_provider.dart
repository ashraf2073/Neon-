import 'package:flutter/foundation.dart';

import '../models/consent.dart';
import '../services/auth_service.dart';

enum AuthStatus { unknown, signedOut, signedIn }

class AuthProvider extends ChangeNotifier {
  AuthProvider(this._service);
  final AuthService _service;

  AuthStatus status = AuthStatus.unknown;
  bool hasAccount = false;
  bool busy = false;
  String? email;
  String? error;
  Consent consent = Consent.none;

  /// Runs at launch: restores the saved session if the user chose to stay signed in.
  Future<void> bootstrap() async {
    hasAccount = await _service.hasAccount();
    consent = await _service.loadConsent();
    email = await _service.restoreSession();
    if (email != null && !consent.dataAccess) email = null;
    status = email != null ? AuthStatus.signedIn : AuthStatus.signedOut;
    notifyListeners();
  }

  Future<bool> submit({
    required String email,
    required String password,
    required Consent consent,
  }) async {
    if (!consent.dataAccess) {
      error = 'Approve data access to continue.';
      notifyListeners();
      return false;
    }
    busy = true;
    error = null;
    notifyListeners();
    try {
      final signedInAs = hasAccount
          ? await _service.signIn(email, password, persist: consent.keepSignedIn)
          : await _service.register(email, password, persist: consent.keepSignedIn);
      await _service.saveConsent(consent);
      this.consent = consent;
      this.email = signedInAs;
      hasAccount = true;
      status = AuthStatus.signedIn;
      busy = false;
      notifyListeners();
      return true;
    } on AuthException catch (e) {
      error = e.message;
    } catch (_) {
      error = 'Something went wrong. Try again.';
    }
    busy = false;
    notifyListeners();
    return false;
  }

  Future<void> updateConsent(Consent next) async {
    await _service.saveConsent(next);
    consent = next;
    notifyListeners();
  }

  Future<void> signOut() async {
    await _service.signOut();
    email = null;
    status = AuthStatus.signedOut;
    notifyListeners();
  }

  /// Withdraw consent: removes the account, consent record and session.
  Future<void> wipe() async {
    await _service.wipe();
    email = null;
    hasAccount = false;
    consent = Consent.none;
    status = AuthStatus.signedOut;
    notifyListeners();
  }
}
