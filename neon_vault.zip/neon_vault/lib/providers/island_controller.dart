import 'dart:async';

import 'package:flutter/material.dart';

import '../core/theme.dart';

enum IslandMode { compact, alert, expanded }

class IslandAlert {
  const IslandAlert(this.message, this.icon, this.color);
  final String message;
  final IconData icon;
  final Color color;
}

/// Drives the Dynamic Island pill. Anything in the app can call push().
class IslandController extends ChangeNotifier {
  IslandMode mode = IslandMode.compact;
  IslandAlert? alert;
  Timer? _timer;

  void toggle() {
    _timer?.cancel();
    mode = mode == IslandMode.expanded ? IslandMode.compact : IslandMode.expanded;
    notifyListeners();
  }

  void collapse() {
    if (mode == IslandMode.compact) return;
    _timer?.cancel();
    mode = IslandMode.compact;
    notifyListeners();
  }

  void push(String message, {IconData icon = Icons.bolt_rounded, Color color = Neon.blue}) {
    if (mode == IslandMode.expanded) return;
    alert = IslandAlert(message, icon, color);
    mode = IslandMode.alert;
    notifyListeners();
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 3200), () {
      mode = IslandMode.compact;
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
