import 'dart:async';

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../models/project.dart';
import '../services/project_repository.dart';
import '../services/uptime_service.dart';
import 'island_controller.dart';

enum SortMode { newest, oldest, nameAz, status, category }

enum ViewMode { grid, list }

enum StatusFilter { all, active, archived }

class ProjectsProvider extends ChangeNotifier {
  ProjectsProvider(this._repo, this._uptime, this._island);

  final ProjectRepository _repo;
  final UptimeService _uptime;
  final IslandController _island;

  List<Project> _all = [];
  bool _loaded = false;
  bool _signedIn = false;
  bool _checksAllowed = false;
  Timer? _timer;

  bool checking = false;
  SortMode sort = SortMode.newest;
  ViewMode view = ViewMode.grid;
  ProjectCategory? categoryFilter;
  StatusFilter statusFilter = StatusFilter.all;
  String query = '';

  // ---- wiring with auth/consent -------------------------------------------

  bool get checksAllowed => _checksAllowed;

  /// Called by the ProxyProvider whenever auth or consent changes.
  void syncWithAuth({required bool signedIn, required bool checksAllowed}) {
    final consentChanged = checksAllowed != _checksAllowed;
    _checksAllowed = checksAllowed;
    if (signedIn && !_signedIn) {
      _signedIn = true;
      Future.microtask(_start);
    } else if (!signedIn && _signedIn) {
      _signedIn = false;
      _loaded = false;
      _timer?.cancel();
      _all = [];
    } else if (signedIn && consentChanged && _loaded && checksAllowed) {
      Future.microtask(() => refreshAll(silent: true));
    }
  }

  Future<void> _start() async {
    _all = await _repo.load();
    _loaded = true;
    notifyListeners();
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(minutes: 5), (_) => refreshAll(silent: true));
    if (_checksAllowed) unawaited(refreshAll(silent: true));
  }

  // ---- read side -----------------------------------------------------------

  int get total => _all.length;
  int get archivedCount => _all.where((p) => p.archived).length;
  int get liveCount => _all.where((p) => stateOf(p) == LiveState.live).length;
  int get downCount => _all.where((p) => stateOf(p) == LiveState.down).length;

  Project? byId(String id) {
    for (final p in _all) {
      if (p.id == id) return p;
    }
    return null;
  }

  /// State shown in the UI. Without consent for checks, nothing claims to be live.
  LiveState stateOf(Project p) {
    if (p.archived) return LiveState.archived;
    if (!_checksAllowed) return LiveState.unchecked;
    return p.liveState;
  }

  List<Project> get visible {
    final q = query.trim().toLowerCase();
    final list = _all.where((p) {
      if (categoryFilter != null && p.category != categoryFilter) return false;
      if (statusFilter == StatusFilter.active && p.archived) return false;
      if (statusFilter == StatusFilter.archived && !p.archived) return false;
      if (q.isEmpty) return true;
      return p.name.toLowerCase().contains(q) ||
          p.description.toLowerCase().contains(q) ||
          p.techStack.any((t) => t.toLowerCase().contains(q));
    }).toList();

    int byName(Project a, Project b) => a.name.toLowerCase().compareTo(b.name.toLowerCase());
    final int Function(Project, Project) cmp = switch (sort) {
      SortMode.newest => (a, b) => b.launchDate.compareTo(a.launchDate),
      SortMode.oldest => (a, b) => a.launchDate.compareTo(b.launchDate),
      SortMode.nameAz => byName,
      SortMode.status => (a, b) {
          final c = (a.archived ? 1 : 0).compareTo(b.archived ? 1 : 0);
          return c != 0 ? c : byName(a, b);
        },
      SortMode.category => (a, b) {
          final c = a.category.index.compareTo(b.category.index);
          return c != 0 ? c : byName(a, b);
        },
    };
    list.sort(cmp);
    return list;
  }

  // ---- toolbar actions -----------------------------------------------------

  void setSort(SortMode v) => _set(() => sort = v);
  void setView(ViewMode v) => _set(() => view = v);
  void setCategory(ProjectCategory? v) => _set(() => categoryFilter = v);
  void setStatusFilter(StatusFilter v) => _set(() => statusFilter = v);
  void setQuery(String v) => _set(() => query = v);
  void clearFilters() => _set(() {
        categoryFilter = null;
        statusFilter = StatusFilter.all;
        query = '';
      });

  void _set(VoidCallback fn) {
    fn();
    notifyListeners();
  }

  // ---- CRUD ----------------------------------------------------------------

  Future<String> storeLogo(String id, String path) => _repo.storeLogo(id, path);

  Future<void> upsert(Project p) async {
    final i = _all.indexWhere((e) => e.id == p.id);
    _all = i == -1 ? [..._all, p] : ([..._all]..[i] = p);
    notifyListeners();
    await _repo.save(_all);
    if (_checksAllowed && !p.archived && p.url.trim().isNotEmpty) unawaited(checkOne(p.id));
  }

  Future<void> remove(String id) async {
    _all = _all.where((p) => p.id != id).toList();
    notifyListeners();
    await _repo.save(_all);
  }

  Future<void> toggleArchive(String id) async {
    final p = byId(id);
    if (p == null) return;
    await upsert(p.archived
        ? p.copyWith(archived: false, clearArchivedAt: true)
        : p.copyWith(archived: true, archivedAt: DateTime.now()));
  }

  Future<void> wipe() => _repo.clear();

  // ---- uptime --------------------------------------------------------------

  Future<void> checkOne(String id, {bool announce = true}) async {
    final p = byId(id);
    if (p == null || p.archived || p.url.trim().isEmpty || !_checksAllowed) return;
    final before = p.lastCheck?.up;
    final r = await _uptime.check(p.url);

    final latest = byId(id); // may have been edited or deleted while we waited
    if (latest == null) return;
    final checks = [
      ...latest.checks,
      UptimeRecord(at: r.at, up: r.up, latencyMs: r.latencyMs, statusCode: r.statusCode),
    ];
    _all = _all
        .map((e) => e.id == id
            ? e.copyWith(
                checks: checks.length > 120 ? checks.sublist(checks.length - 120) : checks,
                serverMeta: r.meta.isNotEmpty ? r.meta : latest.serverMeta,
              )
            : e)
        .toList();
    notifyListeners();
    unawaited(_repo.save(_all));

    if (announce && before != null && before != r.up) {
      _island.push(
        r.up ? '${latest.name} is back online' : '${latest.name} is down',
        icon: r.up ? Icons.check_circle_rounded : Icons.warning_amber_rounded,
        color: r.up ? Neon.mint : Neon.pink,
      );
    }
  }

  Future<void> refreshAll({bool silent = false}) async {
    if (checking) return;
    if (!_checksAllowed) {
      if (!silent) {
        _island.push('Uptime checks are off. Turn them on in Account.',
            icon: Icons.visibility_off_rounded);
      }
      return;
    }
    checking = true;
    notifyListeners();
    final ids = _all
        .where((p) => !p.archived && p.url.trim().isNotEmpty)
        .map((p) => p.id)
        .toList();
    await Future.wait(ids.map((id) => checkOne(id)));
    checking = false;
    notifyListeners();
    if (!silent) {
      _island.push(
        downCount == 0 ? 'All ${ids.length} live projects respond' : '$downCount down of ${ids.length} checked',
        icon: downCount == 0 ? Icons.check_circle_rounded : Icons.warning_amber_rounded,
        color: downCount == 0 ? Neon.mint : Neon.pink,
      );
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
