import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../services/launch_date_service.dart';
import '../utils/age.dart';
import '../widgets/neon.dart';

/// Shows every date found for a link. Pops the chosen DateTime, or null.
class LaunchDateSheet extends StatelessWidget {
  const LaunchDateSheet({super.key, required this.result});
  final LaunchLookupResult result;

  @override
  Widget build(BuildContext context) {
    final found = result.candidates;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            found.isEmpty ? 'No dates found' : 'Pick a launch date',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          Text(
            found.isEmpty
                ? 'Nothing public turned up for this link. Enter the date yourself.'
                : 'A domain date is when the name was registered, which can be earlier than the day the site went live.',
            style: const TextStyle(color: Neon.textLo, fontSize: 13.5, height: 1.4),
          ),
          const SizedBox(height: 16),
          for (var i = 0; i < found.length; i++) ...[
            GlassCard(
              onTap: () => Navigator.pop(context, found[i].date),
              borderColor: i == 0 && found.length > 1 ? Neon.mint.o(.5) : null,
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(formatDate(found[i].date),
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 2),
                        Text(found[i].source,
                            style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600)),
                        Text(found[i].detail,
                            style: const TextStyle(color: Neon.textLo, fontSize: 12.5)),
                      ],
                    ),
                  ),
                  if (i == 0 && found.length > 1)
                    const Text('Earliest', style: TextStyle(color: Neon.mint, fontSize: 12.5)),
                ],
              ),
            ),
            const SizedBox(height: 10),
          ],
          for (final n in result.notes)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(n, style: const TextStyle(color: Neon.textLo, fontSize: 12.5, height: 1.4)),
            ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Keep current date'),
            ),
          ),
        ],
      ),
    );
  }
}
