import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../models/project.dart';
import '../providers/projects_provider.dart';
import '../services/uptime_service.dart';
import '../utils/age.dart';
import '../widgets/neon.dart';

/// Add or edit a project.
class ProjectFormScreen extends StatefulWidget {
  const ProjectFormScreen({super.key, this.existing});
  final Project? existing;

  @override
  State<ProjectFormScreen> createState() => _ProjectFormScreenState();
}

class _ProjectFormScreenState extends State<ProjectFormScreen> {
  final _form = GlobalKey<FormState>();
  late final String _id;
  late final TextEditingController _name, _url, _desc, _purpose, _stack;
  late ProjectCategory _category;
  late DateTime _launch;
  late bool _archived;
  String? _logo;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final p = widget.existing;
    _id = p?.id ?? DateTime.now().microsecondsSinceEpoch.toString();
    _name = TextEditingController(text: p?.name ?? '');
    _url = TextEditingController(text: p?.url ?? '');
    _desc = TextEditingController(text: p?.description ?? '');
    _purpose = TextEditingController(text: p?.purpose ?? '');
    _stack = TextEditingController(text: p?.techStack.join(', ') ?? '');
    _category = p?.category ?? ProjectCategory.web;
    _launch = p?.launchDate ?? DateTime.now();
    _archived = p?.archived ?? false;
    _logo = p?.logoPath;
  }

  @override
  void dispose() {
    for (final c in [_name, _url, _desc, _purpose, _stack]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pickLogo() async {
    final provider = context.read<ProjectsProvider>();
    final file = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxWidth: 512,
      maxHeight: 512,
      imageQuality: 88,
    );
    if (file == null) return;
    final stored = await provider.storeLogo(_id, file.path);
    if (mounted) setState(() => _logo = stored);
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _launch,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (d != null) setState(() => _launch = d);
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    final provider = context.read<ProjectsProvider>();
    final nav = Navigator.of(context);
    final base = widget.existing;
    final wasArchived = base?.archived ?? false;
    final stack = _stack.text
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final project = (base ??
            Project(id: _id, name: '', category: _category, launchDate: _launch))
        .copyWith(
      name: _name.text.trim(),
      category: _category,
      launchDate: _launch,
      description: _desc.text.trim(),
      purpose: _purpose.text.trim(),
      techStack: stack,
      url: _url.text.trim(),
      logoPath: _logo,
      clearLogo: _logo == null,
      archived: _archived,
      archivedAt: _archived && !wasArchived ? DateTime.now() : null,
      clearArchivedAt: !_archived,
    );

    await provider.upsert(project);
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.existing != null;
    final preview = Project(
      id: _id,
      name: _name.text,
      category: _category,
      launchDate: _launch,
      logoPath: _logo,
    );

    return Scaffold(
      appBar: AppBar(title: Text(editing ? 'Edit project' : 'New project')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
          children: [
            Row(
              children: [
                ProjectAvatar(project: preview, size: 64),
                const SizedBox(width: 16),
                Expanded(
                  child: Wrap(
                    spacing: 8,
                    children: [
                      NeonChip(
                        label: _logo == null ? 'Choose logo' : 'Change logo',
                        icon: Icons.image_outlined,
                        selected: false,
                        onTap: _pickLogo,
                      ),
                      if (_logo != null)
                        NeonChip(
                          label: 'Remove',
                          selected: false,
                          onTap: () => setState(() => _logo = null),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(labelText: 'Name'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Give the project a name.' : null,
            ),
            const SizedBox(height: 18),
            const Text('Category', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: [
                for (final c in ProjectCategory.values)
                  NeonChip(
                    label: c.label,
                    icon: c.icon,
                    color: c.color,
                    selected: _category == c,
                    onTap: () => setState(() => _category = c),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            TextFormField(
              controller: _url,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'Link',
                hintText: 'https://yourproject.com',
                prefixIcon: Icon(Icons.link_rounded, color: Neon.textLo),
              ),
              validator: (v) {
                if (v == null || v.trim().isEmpty) return null;
                return UptimeService.normalize(v) == null ? 'Enter a valid link.' : null;
              },
            ),
            const SizedBox(height: 14),
            GlassCard(
              onTap: _pickDate,
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  const Icon(Icons.event_rounded, color: Neon.blue),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Launch date', style: TextStyle(color: Neon.textLo, fontSize: 12.5)),
                        const SizedBox(height: 2),
                        Text(formatDate(_launch),
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                  Text(
                    ProjectAge.between(_launch, DateTime.now()).short,
                    style: const TextStyle(color: Neon.textLo),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _desc,
              maxLines: 2,
              maxLength: 120,
              decoration: const InputDecoration(
                labelText: 'Short description',
                helperText: 'Shown on the project card',
              ),
            ),
            const SizedBox(height: 10),
            TextFormField(
              controller: _purpose,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'About and purpose',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _stack,
              decoration: const InputDecoration(
                labelText: 'Tech stack',
                hintText: 'Flutter, Firebase, Python',
                helperText: 'Separate with commas',
              ),
            ),
            const SizedBox(height: 8),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _archived,
              onChanged: (v) => setState(() => _archived = v),
              title: const Text('Archived', style: TextStyle(fontWeight: FontWeight.w600)),
              subtitle: const Text(
                'Archived projects stop being checked and keep their age frozen.',
                style: TextStyle(color: Neon.textLo, fontSize: 12.5),
              ),
            ),
            const SizedBox(height: 18),
            GradientButton(
              label: editing ? 'Save changes' : 'Add project',
              onPressed: _save,
              busy: _saving,
            ),
          ],
        ),
      ),
    );
  }
}
