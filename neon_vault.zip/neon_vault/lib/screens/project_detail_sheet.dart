import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/theme.dart';
import '../models/project.dart';
import '../providers/projects_provider.dart';
import '../services/uptime_service.dart';
import '../utils/age.dart';
import '../widgets/neon.dart';
import 'project_form_screen.dart';

Future<void> showProjectSheet(BuildContext context, String id) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => _ProjectSheet(id: id),
  );
}

class _ProjectSheet extends StatelessWidget {
  const _ProjectSheet({required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ProjectsProvider>();
    final p = provider.byId(id);
    if (p == null) return const SizedBox.shrink();
    final state = provider.stateOf(p);

    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * .92),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Neon.outline,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                ProjectAvatar(project: p, size: 64),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p.name,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 6,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(p.category.icon, size: 15, color: p.category.color),
                              const SizedBox(width: 4),
                              Text(p.category.label,
                                  style: TextStyle(color: p.category.color, fontSize: 13)),
                            ],
                          ),
                          StatusPill(state),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _AgeCard(p),
            const SizedBox(height: 12),
            _LiveCard(project: p, provider: provider),
            const SizedBox(height: 12),
            _AboutCard(p),
            const SizedBox(height: 16),
            _Actions(project: p),
          ],
        ),
      ),
    );
  }
}

class _AgeCard extends StatelessWidget {
  const _AgeCard(this.p);
  final Project p;

  @override
  Widget build(BuildContext context) {
    final age = p.age;
    return GlassCard(
      borderColor: Neon.blue.o(.5),
      glowColor: Neon.blue,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(p.archived ? 'Ran for' : 'Active for',
              style: const TextStyle(color: Neon.textLo, fontSize: 13)),
          const SizedBox(height: 4),
          Text(age.label, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(
            p.archived && p.archivedAt != null
                ? 'Launched ${formatDate(p.launchDate)}, archived ${formatDate(p.archivedAt!)}.'
                : 'Launched ${formatDate(p.launchDate)}, ${age.totalDays} days ago.',
            style: const TextStyle(color: Neon.textLo, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

class _LiveCard extends StatelessWidget {
  const _LiveCard({required this.project, required this.provider});
  final Project project;
  final ProjectsProvider provider;

  static const _metaLabels = {
    'server': 'Server',
    'last-modified': 'Last modified',
    'content-type': 'Content type',
    'x-powered-by': 'Powered by',
    'date': 'Server clock',
  };

  @override
  Widget build(BuildContext context) {
    final p = project;
    final last = p.lastCheck;
    final hasUrl = p.url.trim().isNotEmpty;
    final canCheck = !p.archived && hasUrl && provider.checksAllowed;

    String? note;
    if (p.archived) {
      note = 'Archived projects are not checked.';
    } else if (!hasUrl) {
      note = 'Add a link to this project to track its uptime.';
    } else if (!provider.checksAllowed) {
      note = 'Uptime checks are off. Turn them on under Account to see live status.';
    } else if (last == null) {
      note = 'No checks yet.';
    }

    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Live status', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          if (note != null)
            Text(note, style: const TextStyle(color: Neon.textLo, fontSize: 13.5, height: 1.4))
          else ...[
            Row(
              children: [
                _Metric('Response', last!.latencyMs != null ? '${last.latencyMs} ms' : 'n/a'),
                _Metric('HTTP', '${last.statusCode ?? 'n/a'}'),
                _Metric(
                  'Uptime',
                  p.uptimePercent == null ? 'n/a' : '${p.uptimePercent!.toStringAsFixed(1)}%',
                ),
              ],
            ),
            const SizedBox(height: 14),
            _Sparkline(p.checks),
            const SizedBox(height: 8),
            Text(
              'Last checked ${timeAgo(last.at)}, ${p.checks.length} checks recorded.',
              style: const TextStyle(color: Neon.textLo, fontSize: 12.5),
            ),
            if (p.serverMeta.isNotEmpty) ...[
              const SizedBox(height: 12),
              for (final e in p.serverMeta.entries)
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: 104,
                        child: Text(_metaLabels[e.key] ?? e.key,
                            style: const TextStyle(color: Neon.textLo, fontSize: 12.5)),
                      ),
                      Expanded(
                        child: Text(e.value,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 12.5)),
                      ),
                    ],
                  ),
                ),
            ],
          ],
          if (canCheck) ...[
            const SizedBox(height: 12),
            NeonChip(
              label: provider.checking ? 'Checking' : 'Check now',
              icon: Icons.sync_rounded,
              selected: false,
              onTap: () => provider.checkOne(p.id, announce: false),
            ),
          ],
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric(this.label, this.value);
  final String label, value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          Text(label, style: const TextStyle(color: Neon.textLo, fontSize: 12.5)),
        ],
      ),
    );
  }
}

/// Last 30 probes as bars: mint = up, pink = down, grey = no data yet.
class _Sparkline extends StatelessWidget {
  const _Sparkline(this.checks);
  final List<UptimeRecord> checks;

  @override
  Widget build(BuildContext context) {
    const slots = 30;
    final recent = checks.length > slots ? checks.sublist(checks.length - slots) : checks;
    return SizedBox(
      height: 26,
      child: Row(
        children: [
          for (var i = 0; i < slots; i++)
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 1.2),
                decoration: BoxDecoration(
                  color: i < slots - recent.length
                      ? Neon.outline
                      : (recent[i - (slots - recent.length)].up ? Neon.mint : Neon.pink),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _AboutCard extends StatelessWidget {
  const _AboutCard(this.p);
  final Project p;

  @override
  Widget build(BuildContext context) {
    final hasText = p.description.isNotEmpty || p.purpose.isNotEmpty;
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('About', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          if (!hasText)
            const Text('No description yet. Edit this project to add one.',
                style: TextStyle(color: Neon.textLo, fontSize: 13.5)),
          if (p.description.isNotEmpty)
            Text(p.description, style: const TextStyle(fontSize: 14, height: 1.45)),
          if (p.purpose.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(p.purpose,
                style: const TextStyle(color: Neon.textLo, fontSize: 13.5, height: 1.45)),
          ],
          const SizedBox(height: 14),
          const Text('Tech stack', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          if (p.techStack.isEmpty)
            const Text('No stack listed.', style: TextStyle(color: Neon.textLo, fontSize: 13.5))
          else
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final t in p.techStack)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Neon.blue.o(.12),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: Neon.blue.o(.4)),
                    ),
                    child: Text(t, style: const TextStyle(fontSize: 12.5)),
                  ),
              ],
            ),
        ],
      ),
    );
  }
}

class _Actions extends StatelessWidget {
  const _Actions({required this.project});
  final Project project;

  @override
  Widget build(BuildContext context) {
    final p = project;
    final uri = UptimeService.normalize(p.url);

    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _ActionTile(
                icon: Icons.open_in_new_rounded,
                label: 'Open link',
                color: Neon.blue,
                onTap: uri == null
                    ? null
                    : () => launchUrl(uri, mode: LaunchMode.externalApplication),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _ActionTile(
                icon: Icons.edit_rounded,
                label: 'Edit',
                color: Neon.textHi,
                onTap: () {
                  final nav = Navigator.of(context);
                  nav.pop();
                  nav.push(MaterialPageRoute(builder: (_) => ProjectFormScreen(existing: p)));
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _ActionTile(
                icon: p.archived ? Icons.unarchive_rounded : Icons.archive_rounded,
                label: p.archived ? 'Restore' : 'Archive',
                color: Neon.violet,
                onTap: () => context.read<ProjectsProvider>().toggleArchive(p.id),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        TextButton.icon(
          style: TextButton.styleFrom(foregroundColor: Neon.pink),
          onPressed: () => _confirmDelete(context),
          icon: const Icon(Icons.delete_outline_rounded),
          label: const Text('Delete project'),
        ),
      ],
    );
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final provider = context.read<ProjectsProvider>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Neon.surfaceHi,
        title: Text('Delete ${project.name}?'),
        content: const Text('This removes it from your dashboard. It cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Keep')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: Neon.pink),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      Navigator.pop(context);
      await provider.remove(project.id);
    }
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: onTap == null ? .4 : 1,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: Container(
          height: 64,
          decoration: BoxDecoration(
            color: Neon.surfaceHi,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Neon.outline),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}
