import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../providers/auth_provider.dart';
import '../providers/projects_provider.dart';
import '../utils/age.dart';

Future<void> showAccountSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    useSafeArea: true,
    isScrollControlled: true,
    builder: (_) => const _AccountSheet(),
  );
}

class _AccountSheet extends StatelessWidget {
  const _AccountSheet();

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final granted = auth.consent.grantedAt;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Account', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(auth.email ?? '', style: const TextStyle(color: Neon.textLo)),
          const SizedBox(height: 18),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: auth.consent.networkChecks,
            onChanged: (v) => auth.updateConsent(auth.consent.copyWith(networkChecks: v)),
            title: const Text('Check my project links',
                style: TextStyle(fontWeight: FontWeight.w600)),
            subtitle: const Text(
              'Contacts only the URLs you added, to measure uptime and read public server headers.',
              style: TextStyle(color: Neon.textLo, fontSize: 12.5),
            ),
          ),
          if (granted != null)
            Padding(
              padding: const EdgeInsets.only(top: 6, bottom: 6),
              child: Text(
                'Data access approved on ${formatDate(granted)}.',
                style: const TextStyle(color: Neon.textLo, fontSize: 12.5),
              ),
            ),
          const Divider(color: Neon.outline, height: 28),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.logout_rounded),
            title: const Text('Sign out'),
            onTap: () {
              final a = context.read<AuthProvider>();
              Navigator.pop(context);
              a.signOut();
            },
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.delete_forever_rounded, color: Neon.pink),
            title: const Text('Withdraw consent and erase data',
                style: TextStyle(color: Neon.pink)),
            subtitle: const Text(
              'Deletes your account, projects and logos from this device.',
              style: TextStyle(color: Neon.textLo, fontSize: 12.5),
            ),
            onTap: () => _confirmWipe(context),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmWipe(BuildContext context) async {
    final auth = context.read<AuthProvider>();
    final projects = context.read<ProjectsProvider>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Neon.surfaceHi,
        title: const Text('Erase everything?'),
        content: const Text(
          'Your account, consent record, projects and logos are removed from this device. This cannot be undone.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Keep')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: Neon.pink),
            child: const Text('Erase'),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      Navigator.pop(context);
      await projects.wipe();
      await auth.wipe();
    }
  }
}
