import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../models/consent.dart';
import '../providers/auth_provider.dart';
import '../widgets/neon.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _obscure = true;
  late bool _data, _checks, _keep, _lookups;

  @override
  void initState() {
    super.initState();
    final c = context.read<AuthProvider>().consent;
    _data = c.dataAccess;
    _checks = c.networkChecks;
    _keep = c.keepSignedIn;
    _lookups = c.registryLookups;
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    await context.read<AuthProvider>().submit(
          email: _email.text,
          password: _password.text,
          consent: Consent(
            dataAccess: _data,
            networkChecks: _checks,
            keepSignedIn: _keep,
            registryLookups: _lookups,
            grantedAt: DateTime.now(),
          ),
        );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final register = !auth.hasAccount;

    return Scaffold(
      body: Stack(
        children: [
          Positioned(top: -140, left: -120, child: _glow(Neon.blue, 340)),
          Positioned(bottom: -160, right: -130, child: _glow(Neon.pink, 360)),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 32, 24, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: Neon.gradient,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: Neon.glow(Neon.pink, blur: 30),
                    ),
                    child: const Icon(Icons.hub_rounded, size: 28),
                  ),
                  const SizedBox(height: 28),
                  Text(
                    register ? 'Create your vault' : 'Welcome back',
                    style: const TextStyle(
                        fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: -.6),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    register
                        ? 'One account on this device keeps every app, site and project you have shipped in one place.'
                        : 'Sign in to see how your projects are doing.',
                    style: const TextStyle(color: Neon.textLo, fontSize: 15, height: 1.4),
                  ),
                  const SizedBox(height: 28),
                  TextField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const [AutofillHints.email],
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      prefixIcon: Icon(Icons.mail_outline_rounded, color: Neon.textLo),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _password,
                    obscureText: _obscure,
                    autofillHints: const [AutofillHints.password],
                    onSubmitted: (_) => _data ? _submit() : null,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      helperText: register ? 'At least 8 characters' : null,
                      prefixIcon: const Icon(Icons.lock_outline_rounded, color: Neon.textLo),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => _obscure = !_obscure),
                        icon: Icon(
                          _obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                          color: Neon.textLo,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  GlassCard(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    child: Column(
                      children: [
                        _ConsentTile(
                          value: _data,
                          onChanged: (v) => setState(() => _data = v),
                          title: 'Store my data on this device',
                          tag: 'Required',
                          tagColor: Neon.pink,
                          detail:
                              'I approve access to my email, a hashed password and the project details I enter.',
                        ),
                        _ConsentTile(
                          value: _checks,
                          onChanged: (v) => setState(() => _checks = v),
                          title: 'Check my project links',
                          tag: 'Optional',
                          detail:
                              'I approve contacting the URLs I add to measure uptime and read public server headers.',
                        ),
                        _ConsentTile(
                          value: _lookups,
                          onChanged: (v) => setState(() => _lookups = v),
                          title: 'Look up launch dates',
                          tag: 'Optional',
                          detail:
                              'I approve sending a domain or repository name to the domain registry, the Internet Archive and GitHub when I ask for a launch date.',
                        ),
                        _ConsentTile(
                          value: _keep,
                          onChanged: (v) => setState(() => _keep = v),
                          title: 'Keep me signed in',
                          tag: 'Optional',
                          detail: 'I approve saving my session on this device.',
                        ),
                      ],
                    ),
                  ),
                  if (auth.error != null) ...[
                    const SizedBox(height: 14),
                    Text(auth.error!, style: const TextStyle(color: Neon.pink, fontSize: 14)),
                  ],
                  const SizedBox(height: 22),
                  GradientButton(
                    label: register ? 'Create account' : 'Sign in',
                    onPressed: _data ? _submit : null,
                    busy: auth.busy,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Passwords are salted, hashed and kept in the Android Keystore. You can withdraw consent and erase local data any time under Account.',
                    style: TextStyle(color: Neon.textLo, fontSize: 12.5, height: 1.45),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _glow(Color c, double size) => IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [c.o(.28), c.o(0)]),
          ),
        ),
      );
}

class _ConsentTile extends StatelessWidget {
  const _ConsentTile({
    required this.value,
    required this.onChanged,
    required this.title,
    required this.detail,
    required this.tag,
    this.tagColor = Neon.textLo,
  });

  final bool value;
  final ValueChanged<bool> onChanged;
  final String title, detail, tag;
  final Color tagColor;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => onChanged(!value),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Checkbox(
              value: value,
              onChanged: (v) => onChanged(v ?? false),
              visualDensity: VisualDensity.compact,
              materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(title,
                              style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                        ),
                        const SizedBox(width: 8),
                        Text(tag, style: TextStyle(fontSize: 12, color: tagColor)),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(detail,
                        style: const TextStyle(fontSize: 12.5, color: Neon.textLo, height: 1.4)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
