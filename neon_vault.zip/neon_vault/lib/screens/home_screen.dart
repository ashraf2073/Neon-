import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../models/project.dart';
import '../providers/island_controller.dart';
import '../providers/projects_provider.dart';
import '../widgets/dynamic_island.dart';
import '../widgets/neon.dart';
import '../widgets/project_card.dart';
import '../widgets/sort_filter_bar.dart';
import 'account_sheet.dart';
import 'project_detail_sheet.dart';
import 'project_form_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _add(BuildContext context) => Navigator.of(context)
      .push(MaterialPageRoute(builder: (_) => const ProjectFormScreen()));

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ProjectsProvider>();
    final island = context.watch<IslandController>();
    final top = MediaQuery.paddingOf(context).top;
    final items = p.visible;
    final list = p.view == ViewMode.list;
    final expanded = island.mode == IslandMode.expanded;

    Widget item(int i) {
      final pr = items[i];
      return ProjectCard(
        project: pr,
        list: list,
        onTap: () => showProjectSheet(context, pr.id),
      )
          .animate(key: ValueKey('${pr.id}-${p.view.name}-${p.sort.name}'))
          .fadeIn(duration: 260.ms, delay: (30 * math.min(i, 8)).ms)
          .moveY(begin: 10, end: 0, curve: Curves.easeOutCubic);
    }

    return Scaffold(
      floatingActionButton: SizedBox(
        width: 172,
        child: GradientButton(
          label: 'Add project',
          icon: Icons.add_rounded,
          onPressed: () => _add(context),
        ),
      ),
      body: Stack(
        children: [
          RefreshIndicator(
            color: Neon.pink,
            backgroundColor: Neon.surfaceHi,
            edgeOffset: top + 60,
            onRefresh: () => p.refreshAll(),
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: SizedBox(height: top + 64)),
                SliverToBoxAdapter(child: _Header(p)),
                const SliverToBoxAdapter(child: SortFilterBar()),
                const SliverToBoxAdapter(child: SizedBox(height: 16)),
                if (items.isEmpty)
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: _EmptyState(
                      filtered: p.total > 0,
                      onAdd: () => _add(context),
                      onClear: p.clearFilters,
                    ),
                  )
                else if (list)
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    sliver: SliverList.separated(
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) => item(i),
                    ),
                  )
                else
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    sliver: SliverGrid.builder(
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 12,
                        crossAxisSpacing: 12,
                        mainAxisExtent: 214,
                      ),
                      itemCount: items.length,
                      itemBuilder: (_, i) => item(i),
                    ),
                  ),
                const SliverToBoxAdapter(child: SizedBox(height: 110)),
              ],
            ),
          ),
          // Dims the dashboard while the island is open; tap to close.
          Positioned.fill(
            child: IgnorePointer(
              ignoring: !expanded,
              child: AnimatedOpacity(
                opacity: expanded ? 1 : 0,
                duration: const Duration(milliseconds: 250),
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: island.collapse,
                  child: const ColoredBox(color: Color(0xB3000000)),
                ),
              ),
            ),
          ),
          DynamicIsland(
            onAdd: () => _add(context),
            onRefresh: () => p.refreshAll(),
            onAccount: () => showAccountSheet(context),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header(this.p);
  final ProjectsProvider p;

  @override
  Widget build(BuildContext context) {
    final sub = !p.checksAllowed
        ? '${p.total} tracked'
        : '${p.total} tracked, ${p.liveCount} online${p.downCount > 0 ? ', ${p.downCount} down' : ''}';
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Your projects',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -.5),
          ),
          const SizedBox(height: 4),
          Text(sub, style: const TextStyle(color: Neon.textLo, fontSize: 14)),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.filtered, required this.onAdd, required this.onClear});
  final bool filtered;
  final VoidCallback onAdd, onClear;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Neon.surface,
              border: Border.all(color: Neon.outline),
            ),
            child: const Icon(Icons.folder_open_rounded, size: 32, color: Neon.textLo),
          ),
          const SizedBox(height: 16),
          Text(
            filtered ? 'No projects match' : 'Nothing tracked yet',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Text(
            filtered
                ? 'Clear the search or filters to see everything.'
                : 'Add your first app, website or portfolio.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Neon.textLo),
          ),
          const SizedBox(height: 16),
          TextButton(
            onPressed: filtered ? onClear : onAdd,
            child: Text(filtered ? 'Clear filters' : 'Add project'),
          ),
        ],
      ),
    );
  }
}
