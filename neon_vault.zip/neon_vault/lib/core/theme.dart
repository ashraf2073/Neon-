import 'package:flutter/material.dart';

/// Design tokens: midnight black, electric blue, neon pink.
class Neon {
  Neon._();

  static const midnight = Color(0xFF04050A);
  static const surface = Color(0xFF0C0E17);
  static const surfaceHi = Color(0xFF141726);
  static const outline = Color(0xFF232842);

  static const blue = Color(0xFF2F6BFF); // electric blue
  static const pink = Color(0xFFFF2E9A); // neon pink
  static const violet = Color(0xFF9B6BFF);
  static const mint = Color(0xFF2CF5A0); // "online" signal only

  static const textHi = Color(0xFFF1F3FF);
  static const textLo = Color(0xFF8C93B3);

  static const gradient = LinearGradient(
    colors: [blue, pink],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static List<BoxShadow> glow(Color c, {double blur = 20, double opacity = .35}) =>
      [BoxShadow(color: c.o(opacity), blurRadius: blur, spreadRadius: -4)];
}

extension NeonColor on Color {
  /// Opacity helper that works on every Flutter version.
  Color o(double opacity) => withAlpha((opacity.clamp(0.0, 1.0) * 255).round());
}

ThemeData buildNeonTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  OutlineInputBorder border(Color c, [double w = 1]) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: c, width: w),
      );

  return base.copyWith(
    scaffoldBackgroundColor: Neon.midnight,
    colorScheme: const ColorScheme.dark(
      primary: Neon.blue,
      secondary: Neon.pink,
      surface: Neon.surface,
      error: Neon.pink,
    ),
    textTheme: base.textTheme.apply(bodyColor: Neon.textHi, displayColor: Neon.textHi),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Neon.surface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: border(Neon.outline),
      enabledBorder: border(Neon.outline),
      focusedBorder: border(Neon.blue, 1.6),
      errorBorder: border(Neon.pink),
      focusedErrorBorder: border(Neon.pink, 1.6),
      hintStyle: const TextStyle(color: Neon.textLo),
      labelStyle: const TextStyle(color: Neon.textLo),
    ),
    checkboxTheme: CheckboxThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      side: const BorderSide(color: Neon.textLo, width: 1.5),
      fillColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? Neon.blue : Colors.transparent,
      ),
      checkColor: const WidgetStatePropertyAll(Colors.white),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: const WidgetStatePropertyAll(Colors.white),
      trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? Neon.blue : Neon.outline,
      ),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: Neon.surfaceHi,
      behavior: SnackBarBehavior.floating,
      contentTextStyle: TextStyle(color: Neon.textHi),
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: Neon.surface,
      modalBackgroundColor: Neon.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
      ),
    ),
  );
}
