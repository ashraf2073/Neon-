import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../models/project.dart';
import '../providers/projects_provider.dart';
import 'neon.dart';

/// One project, drawn as a grid tile or a list row.
class ProjectCard extends StatelessWidget {
  const ProjectCard({
    super.key,
    required this.project,
    required this.list,
    required this.onTap,
  });

  final Project project;
  final bool list;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final state = context.select<ProjectsProvider, LiveState>((v) => v.stateOf(project));
    return list ? _row(state) : _tile(state);
  }

  Widget _tile(LiveState state) {
    final p = project;
    return GlassCard(
      onTap: onTap,
      padding: const EdgeInsets.all(14),
      borderColor: state == LiveState.down ? Neon.pink.o(.55) : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ProjectAvatar(project: p, size: 44),
              const Spacer(),
              Container(
                width: 9,
                height: 9,
                decoration: BoxDecoration(
                  color: state.color,
                  shape: BoxShape.circle,
                  boxShadow: state == LiveState.live || state == LiveState.down
                      ? Neon.glow(state.color, blur: 10, opacity: .9)
                      : null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            p.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              Icon(p.category.icon, size: 13, color: p.category.color),
              const SizedBox(width: 4),
              Text(p.category.label,
                  style: TextStyle(color: p.category.color, fontSize: 12.5)),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: Text(
              p.description.isEmpty ? 'No description yet' : p.description,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Neon.textLo, fontSize: 12.5, height: 1.35),
            ),
          ),
          Row(
            children: [
              const Icon(Icons.schedule_rounded, size: 14, color: Neon.textLo),
              const SizedBox(width: 4),
              Text(p.age.short, style: const TextStyle(color: Neon.textLo, fontSize: 12.5)),
              const Spacer(),
              Text(state.label,
                  style: TextStyle(
                      color: state.color, fontSize: 12.5, fontWeight: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _row(LiveState state) {
    final p = project;
    return GlassCard(
      onTap: onTap,
      padding: const EdgeInsets.all(12),
      borderColor: state == LiveState.down ? Neon.pink.o(.55) : null,
      child: Row(
        children: [
          ProjectAvatar(project: p, size: 52),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        p.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Icon(p.category.icon, size: 14, color: p.category.color),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  p.description.isEmpty ? p.category.label : p.description,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Neon.textLo, fontSize: 12.5),
                ),
                const SizedBox(height: 6),
                Text(
                  '${p.archived ? 'Ran for' : 'Active for'} ${p.age.label}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Neon.textLo, fontSize: 12.5),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          StatusPill(state),
        ],
      ),
    );
  }
}
