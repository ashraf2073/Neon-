import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../models/project.dart';
import '../providers/projects_provider.dart';
import 'neon.dart';

/// Search, view switch, sort chips and filter chips.
class SortFilterBar extends StatelessWidget {
  const SortFilterBar({super.key});

  static const _sorts = <(SortMode, String, IconData)>[
    (SortMode.newest, 'Newest first', Icons.south_rounded),
    (SortMode.oldest, 'Oldest first', Icons.north_rounded),
    (SortMode.nameAz, 'A to Z', Icons.sort_by_alpha_rounded),
    (SortMode.status, 'Active first', Icons.bolt_rounded),
    (SortMode.category, 'By category', Icons.category_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    final p = context.watch<ProjectsProvider>();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: p.setQuery,
                  textInputAction: TextInputAction.search,
                  decoration: const InputDecoration(
                    hintText: 'Search name, stack or description',
                    prefixIcon: Icon(Icons.search_rounded, color: Neon.textLo),
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              _ViewToggle(view: p.view, onChanged: p.setView),
            ],
          ),
        ),
        const SizedBox(height: 12),
        _ChipRow(children: [
          for (final (mode, label, icon) in _sorts)
            NeonChip(
              label: label,
              icon: icon,
              selected: p.sort == mode,
              onTap: () => p.setSort(mode),
            ),
        ]),
        const SizedBox(height: 10),
        _ChipRow(children: [
          NeonChip(
            label: 'All',
            selected: p.categoryFilter == null,
            onTap: () => p.setCategory(null),
          ),
          for (final c in ProjectCategory.values)
            NeonChip(
              label: switch (c) {
                ProjectCategory.app => 'Apps',
                ProjectCategory.web => 'Websites',
                ProjectCategory.portfolio => 'Portfolio',
              },
              icon: c.icon,
              color: c.color,
              selected: p.categoryFilter == c,
              onTap: () => p.setCategory(p.categoryFilter == c ? null : c),
            ),
          NeonChip(
            label: 'Active',
            color: Neon.mint,
            selected: p.statusFilter == StatusFilter.active,
            onTap: () => p.setStatusFilter(
                p.statusFilter == StatusFilter.active ? StatusFilter.all : StatusFilter.active),
          ),
          NeonChip(
            label: 'Archived',
            color: Neon.violet,
            selected: p.statusFilter == StatusFilter.archived,
            onTap: () => p.setStatusFilter(
                p.statusFilter == StatusFilter.archived ? StatusFilter.all : StatusFilter.archived),
          ),
        ]),
      ],
    );
  }
}

class _ChipRow extends StatelessWidget {
  const _ChipRow({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: children.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) => Center(child: children[i]),
      ),
    );
  }
}

class _ViewToggle extends StatelessWidget {
  const _ViewToggle({required this.view, required this.onChanged});
  final ViewMode view;
  final ValueChanged<ViewMode> onChanged;

  @override
  Widget build(BuildContext context) {
    Widget item(ViewMode mode, IconData icon) {
      final on = view == mode;
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => onChanged(mode),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            gradient: on ? Neon.gradient : null,
            borderRadius: BorderRadius.circular(13),
          ),
          child: Icon(icon, size: 20, color: on ? Colors.white : Neon.textLo),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: Neon.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Neon.outline),
      ),
      child: Row(
        children: [
          item(ViewMode.grid, Icons.grid_view_rounded),
          item(ViewMode.list, Icons.view_agenda_rounded),
        ],
      ),
    );
  }
}
