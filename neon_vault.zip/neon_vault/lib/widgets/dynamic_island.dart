import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../providers/island_controller.dart';
import '../providers/projects_provider.dart';

/// Pill at the top of the screen. Three states:
///  compact  - live count, pulsing dot
///  alert    - transient message (site down, back online, check finished)
///  expanded - project stats and shortcuts
/// Place it last in a Stack so it floats over the content.
class DynamicIsland extends StatelessWidget {
  const DynamicIsland({
    super.key,
    required this.onAdd,
    required this.onRefresh,
    required this.onAccount,
  });

  final VoidCallback onAdd, onRefresh, onAccount;

  @override
  Widget build(BuildContext context) {
    final island = context.watch<IslandController>();
    final p = context.watch<ProjectsProvider>();
    final screenW = MediaQuery.sizeOf(context).width;
    final top = MediaQuery.paddingOf(context).top + 6;

    final (w, h, r) = switch (island.mode) {
      IslandMode.compact => (146.0, 38.0, 20.0),
      IslandMode.alert => (math.min(screenW - 40, 340.0), 52.0, 26.0),
      IslandMode.expanded => (screenW - 32, 188.0, 34.0),
    };

    final accent = switch (island.mode) {
      IslandMode.alert => island.alert?.color ?? Neon.blue,
      _ => p.downCount > 0
          ? Neon.pink
          : (p.liveCount > 0 ? Neon.mint : Neon.blue),
    };

    final content = switch (island.mode) {
      IslandMode.compact => _compact(p, accent),
      IslandMode.alert => _alert(island.alert),
      IslandMode.expanded => _expanded(p, island),
    };

    return Positioned(
      top: top,
      left: 0,
      right: 0,
      child: Align(
        alignment: Alignment.topCenter,
        child: GestureDetector(
          onTap: island.toggle,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 420),
            curve: Curves.easeOutCubic,
            width: w,
            height: h,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(r),
              border: Border.all(
                color: accent.o(island.mode == IslandMode.compact ? .35 : .65),
              ),
              boxShadow: Neon.glow(accent, blur: 26, opacity: .28),
            ),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 240),
              child: OverflowBox(
                key: ValueKey(island.mode),
                alignment: Alignment.center,
                minWidth: w,
                maxWidth: w,
                minHeight: h,
                maxHeight: h,
                child: content,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _compact(ProjectsProvider p, Color accent) {
    final label = p.checking
        ? 'Checking'
        : !p.checksAllowed
            ? '${p.total} projects'
            : p.downCount > 0
                ? '${p.downCount} down'
                : '${p.liveCount} online';
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _PulseDot(color: accent, pulsing: p.checking || p.downCount > 0),
        const SizedBox(width: 8),
        Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
      ],
    );
  }

  Widget _alert(IslandAlert? a) {
    if (a == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Row(
        children: [
          Icon(a.icon, color: a.color, size: 22),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              a.message,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _expanded(ProjectsProvider p, IslandController island) {
    void run(VoidCallback fn) {
      island.collapse();
      fn();
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Text('Portfolio pulse', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
              Spacer(),
              Icon(Icons.keyboard_arrow_up_rounded, color: Neon.textLo),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _Stat('${p.total}', 'Projects', Neon.textHi),
              _Stat('${p.liveCount}', 'Online', Neon.mint),
              _Stat('${p.downCount}', 'Down', Neon.pink),
              _Stat('${p.archivedCount}', 'Archived', Neon.violet),
            ],
          ),
          const Spacer(),
          Row(
            children: [
              Expanded(child: _Shortcut(Icons.add_rounded, 'Add', () => run(onAdd))),
              const SizedBox(width: 8),
              Expanded(child: _Shortcut(Icons.sync_rounded, 'Check now', () => run(onRefresh))),
              const SizedBox(width: 8),
              Expanded(child: _Shortcut(Icons.person_outline_rounded, 'Account', () => run(onAccount))),
            ],
          ),
        ],
      ),
    );
  }
}

class _PulseDot extends StatelessWidget {
  const _PulseDot({required this.color, required this.pulsing});
  final Color color;
  final bool pulsing;

  @override
  Widget build(BuildContext context) {
    final dot = Container(
      width: 8,
      height: 8,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        boxShadow: Neon.glow(color, blur: 8, opacity: .9),
      ),
    );
    if (!pulsing) return dot;
    return dot
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .scale(begin: const Offset(.8, .8), end: const Offset(1.3, 1.3), duration: 800.ms);
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.value, this.label, this.color);
  final String value, label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color)),
          Text(label, style: const TextStyle(fontSize: 12, color: Neon.textLo)),
        ],
      ),
    );
  }
}

class _Shortcut extends StatelessWidget {
  const _Shortcut(this.icon, this.label, this.onTap);
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        height: 42,
        decoration: BoxDecoration(
          color: Colors.white.o(.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Neon.outline),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 17, color: Neon.blue),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
