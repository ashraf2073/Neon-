import 'dart:io';

import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../models/project.dart';

class GlassCard extends StatelessWidget {
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.borderColor,
    this.glowColor,
  });

  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final Color? borderColor, glowColor;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(22);
    return Container(
      decoration: BoxDecoration(
        color: Neon.surface,
        borderRadius: radius,
        border: Border.all(color: borderColor ?? Neon.outline),
        boxShadow: glowColor == null ? null : Neon.glow(glowColor!, blur: 22, opacity: .22),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: radius,
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          splashColor: Neon.blue.o(.12),
          highlightColor: Colors.transparent,
          child: Padding(padding: padding, child: child),
        ),
      ),
    );
  }
}

class GradientButton extends StatelessWidget {
  const GradientButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.busy = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool busy;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !busy;
    final radius = BorderRadius.circular(18);
    return AnimatedOpacity(
      opacity: onPressed == null ? .4 : 1,
      duration: const Duration(milliseconds: 200),
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          gradient: Neon.gradient,
          borderRadius: radius,
          boxShadow: enabled ? Neon.glow(Neon.pink, blur: 24, opacity: .35) : null,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: radius,
            onTap: enabled ? onPressed : null,
            child: Center(
              child: busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white),
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 8)],
                        Text(label,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

class NeonChip extends StatelessWidget {
  const NeonChip({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
    this.color = Neon.blue,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? color.o(.16) : Neon.surface,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: selected ? color : Neon.outline),
          boxShadow: selected ? Neon.glow(color, blur: 14, opacity: .25) : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 15, color: selected ? color : Neon.textLo),
              const SizedBox(width: 6),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: selected ? Neon.textHi : Neon.textLo,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Uploaded logo, or a gradient tile with the project's initial.
class ProjectAvatar extends StatelessWidget {
  const ProjectAvatar({super.key, required this.project, this.size = 48});
  final Project project;
  final double size;

  @override
  Widget build(BuildContext context) {
    final logo = project.logoPath;
    final file = (logo != null && File(logo).existsSync()) ? File(logo) : null;
    final c = project.category.color;
    final initial = project.name.trim().isEmpty ? '?' : project.name.trim()[0].toUpperCase();
    return ClipRRect(
      borderRadius: BorderRadius.circular(size * .3),
      child: SizedBox(
        width: size,
        height: size,
        child: file != null
            ? Image.file(file, fit: BoxFit.cover, cacheWidth: (size * 3).round())
            : DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [c.o(.9), c.o(.3)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Center(
                  child: Text(
                    initial,
                    style: TextStyle(
                      fontSize: size * .42,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
      ),
    );
  }
}

extension LiveStateX on LiveState {
  String get label => switch (this) {
        LiveState.live => 'Online',
        LiveState.down => 'Down',
        LiveState.unchecked => 'Not checked',
        LiveState.archived => 'Archived',
      };

  Color get color => switch (this) {
        LiveState.live => Neon.mint,
        LiveState.down => Neon.pink,
        LiveState.unchecked => Neon.textLo,
        LiveState.archived => Neon.violet,
      };
}

class StatusPill extends StatelessWidget {
  const StatusPill(this.state, {super.key});
  final LiveState state;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: state.color.o(.14),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: state.color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 6),
          Text(
            state.label,
            style: TextStyle(color: state.color, fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
