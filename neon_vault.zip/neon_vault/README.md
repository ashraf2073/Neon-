# Neon Vault

Personal dashboard that tracks every app, website and portfolio project you have shipped.
Flutter, Android first. Midnight black, electric blue, neon pink, with a Dynamic Island pill.

## Build the APK

    cd neon_vault
    ./build_apk.sh

The script scaffolds the Android project in `app/`, copies `lib/` and `pubspec.yaml` in,
adds the INTERNET permission and runs `flutter build apk --release`.
Result: `app/build/app/outputs/flutter-apk/app-release.apk`.

Manual route (Windows): `flutter create --platforms=android app`, copy `lib/` and
`pubspec.yaml` over, add `<uses-permission android:name="android.permission.INTERNET"/>`
to `android/app/src/main/AndroidManifest.xml`, then `flutter pub get` and `flutter build apk --release`.

## Structure

    lib/
      main.dart                      providers, auth gate, system bars
      core/theme.dart                colours, glow, ThemeData
      models/                        Project, UptimeRecord, Consent
      utils/age.dart                 years/months/days calculator, date helpers
      services/
        auth_service.dart            AuthService interface + LocalAuthService (Keystore)
        project_repository.dart      JSON persistence, logo storage, sample data
        uptime_service.dart          HTTP probe + response header metadata
      providers/
        auth_provider.dart           session, consent, sign in/out, wipe
        projects_provider.dart       list, sort, filter, view mode, uptime checks
        island_controller.dart       compact / alert / expanded island state
      widgets/                       Dynamic Island, cards, toolbar, shared bits
      screens/                       login, home, form, project sheet, account sheet

## Consent

The sign-in screen has three checkboxes: store data on device (required), check project
links for uptime (optional), keep me signed in (optional). Choices and the date are stored,
can be changed under Account, and "Withdraw consent and erase data" wipes everything.
With uptime checks off, no network request is made and nothing is shown as online.

## Uptime and age

- Age: calendar-accurate from the launch date ("Active for 2 years, 3 months", plus exact days).
  Archived projects freeze at the archive date.
- Uptime: HEAD request (GET fallback) every 5 minutes while the app is open, on pull-to-refresh
  and on "Check now". Anything below HTTP 500 counts as up. Latency, status code, uptime
  percentage over the last 120 checks and public headers (server, last-modified, content-type)
  are shown in the project sheet. Apps without a link show "Not checked".

## Notes

- The local login is a prototype: one account per device, salted and iterated SHA-256 in
  `flutter_secure_storage`. For Firebase, implement `AuthService` with `firebase_auth` and
  swap it in `main.dart`.
- Release builds are debug-signed, fine for sideloading. Sign with your own keystore for the Play Store.
- If the build complains about `minSdk`, set `minSdk = 23` in `android/app/build.gradle(.kts)`.
- Plain `http://` links are blocked on Android 9+ unless you add `android:usesCleartextTraffic="true"`.
- Sample projects are seeded on first launch. Delete them from their project sheet.
