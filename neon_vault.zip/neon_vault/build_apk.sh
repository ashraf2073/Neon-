#!/usr/bin/env bash
# Builds a sideloadable APK. Needs Flutter (stable) and the Android SDK.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
APP="$HERE/app"

if [ ! -d "$APP" ]; then
  flutter create --org com.neonvault --project-name neon_vault --platforms=android "$APP"
fi

rm -rf "$APP/lib"
cp -R "$HERE/lib" "$APP/lib"
cp "$HERE/pubspec.yaml" "$APP/pubspec.yaml"

MANIFEST="$APP/android/app/src/main/AndroidManifest.xml"
# The uptime checker needs network access in release builds.
if ! grep -q "android.permission.INTERNET" "$MANIFEST"; then
  sed -i.bak 's|<application|<uses-permission android:name="android.permission.INTERNET"/>\n    <application|' "$MANIFEST"
  rm -f "$MANIFEST.bak"
fi
sed -i.bak 's|android:label="[^"]*"|android:label="Neon Vault"|' "$MANIFEST" && rm -f "$MANIFEST.bak"

cd "$APP"
flutter pub get
flutter build apk --release
echo
echo "APK: $APP/build/app/outputs/flutter-apk/app-release.apk"
